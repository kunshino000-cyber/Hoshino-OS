# Hoshino OS — bộ khung xây dựng ISO (bản khởi đầu)

Đây là **bộ mã nguồn/cấu hình khởi đầu**, chưa phải file ISO đã build hoặc kiểm thử.
Mục tiêu: Debian 13 (trixie) 64-bit + XFCE, phong cách pastel xanh/hồng, nền SVG riêng,
Plank dock, Conky widget và compositor nhẹ.

## Lưu ý cho máy của bạn
- ASUS K40IJ, Intel Core 2 Duo T6600, RAM 4 GB, BIOS Legacy.
- File ISO Hoshino OS hoàn chỉnh chưa được tạo. ZIP này chứa cấu hình và workflow để build trên máy Linux/CI có Internet.
- Không thể tạo ISO bằng cách nhấp đúp trong Windows. Không xóa Windows hoặc sửa phân vùng để boot bộ cài trước khi có phương án khởi động đã kiểm chứng.

## Cách build
### Cách A — trên máy Linux Debian/Ubuntu có Internet
1. Giải nén ZIP.
2. Mở terminal trong thư mục dự án.
3. Chạy `sudo apt update && sudo apt install live-build debootstrap xorriso squashfs-tools`.
4. Chạy `sudo ./build.sh`.
5. Nếu thành công, ISO sẽ nằm trong thư mục dự án.

### Cách B — build từ GitHub Actions (không tải công cụ build về máy yếu)
1. Tạo một repository GitHub mới.
2. Upload toàn bộ nội dung thư mục này lên repository.
3. Mở tab **Actions**, chọn workflow **Build Hoshino OS ISO**, rồi bấm **Run workflow**.
4. Khi workflow thành công, mở lần chạy đó và tải artifact `hoshino-os-iso`.

GitHub Actions yêu cầu tài khoản GitHub và repository; tùy thiết lập tài khoản, có thể cần bật Actions. Workflow được chuẩn bị nhưng chưa được chạy/kiểm thử trong gói này.

## Thành phần
- Debian 13 amd64 + XFCE
- Plank dock
- Conky widget đồng hồ/thông tin hệ thống
- Hình nền pastel SVG tự tạo
- Màu GTK pastel cơ bản

## Trạng thái
- [x] Cấu hình nền và danh sách gói
- [x] Hình nền SVG và cấu hình giao diện cơ bản
- [x] Script build ISO
- [x] GitHub Actions workflow để build trên runner có Internet
- [ ] Build ISO thực tế
- [ ] Kiểm thử boot BIOS Legacy
- [ ] Kiểm thử installer và cài đặt trên máy thật
- [ ] Tinh chỉnh hiệu ứng Liquid Glass/animation theo GPU đời cũ

## Giới hạn thiết kế
XFCE không có Liquid Glass giống iOS/macOS nguyên bản. Gói hiện tại tạo nền pastel, bảng kính mô phỏng, dock và widget; hiệu ứng sẽ được giữ nhẹ cho máy cũ. Đây là bản khởi đầu, không nên cài lên máy chính trước khi kiểm thử.
