#!/usr/bin/env bash
set -Eeuo pipefail

# Build Hoshino OS live ISO inside Debian 13 (trixie) amd64.
# This script is for a Linux build environment, NOT Windows CMD.

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Run with sudo: sudo ./build.sh"
  exit 1
fi

for cmd in lb debootstrap xorriso mksquashfs; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing build tool: $cmd"
    echo "Install on Debian/Ubuntu: apt update && apt install live-build debootstrap xorriso squashfs-tools"
    exit 2
  fi
done

cd "$(dirname "$0")"
if [[ ! -x auto/config ]]; then
  echo "auto/config is missing or not executable."
  exit 3
fi

lb config
lb build

shopt -s nullglob
isos=( ./*.iso )
if (( ${#isos[@]} == 0 )); then
  echo "Build finished but no ISO was found in the project directory. Check the log above."
  exit 4
fi
printf '\nISO output(s):\n'
printf ' - %s (%s)\n' "${isos[@]}" "$(du -h "${isos[@]}" | cut -f1)"
